package com.stylefeng.guns.modular.restapi.model;

public class TypeUserArea {
	// 用户数量
	private int count;
	// 所在城市
	private String city;
	// 百分比
	private String countPercent;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountPercent() {
		return countPercent;
	}

	public void setCountPercent(String countPercent) {
		this.countPercent = countPercent;
	}

}
